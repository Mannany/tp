'use strict';

/***********************************************************************************/
/* *********************************** DONNEES *************************************/
/***********************************************************************************/

const rocket = document.getElementById('rocket');
const firingButton = document.getElementById('firing-button');
const billboard = document.querySelector('#billboard span');

let countdown = 10;
let countdownInterval;

/***********************************************************************************/
/* ********************************** FONCTIONS ************************************/
/***********************************************************************************/

function startCountdown() {
    firingButton.removeEventListener('click', startCountdown);
    billboard.textContent = countdown;

    countdownInterval = setInterval(() => {
        countdown--;

        if (countdown > 0) {
            billboard.textContent = countdown;
        } else {
            clearInterval(countdownInterval);
            billboard.textContent = 'Décollage !';
            billboard.style.fontSize = '2em';
            launchRocket();
        }
    }, 1000);
}

function launchRocket() {
    rocket.style.transition = 'transform 4s ease-in-out';
    rocket.style.transform = 'translateY(-1000px) rotate(-45deg)';
}

function resetRocket() {
    window.location.reload();
}

/************************************************************************************/
/* ******************************** CODE PRINCIPAL **********************************/
/************************************************************************************/

firingButton.addEventListener('click', startCountdown);
rocket.addEventListener('click', resetRocket);