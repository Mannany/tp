// Variables globales
let gameState;
const gameContainer = document.getElementById('gameContainer');

// Fonction pour lancer des dés
function rollDice(n, faces) {
    let total = 0;
    for (let i = 0; i < n; i++) {
        total += Math.floor(Math.random() * faces) + 1;
    }
    return total;
}

// Initialisation du jeu
function initGame(difficulty) {
    gameState = {
        dragon: { hp: 0, maxHP: 0 },
        knight: { hp: 0, maxHP: 0 },
        difficulty: difficulty.toLowerCase(),
        round: 0
    };
    
    // Initialisation des PV
    initHealthPoints();
    playGame();
}

// Initialisation des points de vie
function initHealthPoints() {
    switch(gameState.difficulty) {
        case 'facile':
            gameState.dragon.hp = 100 + rollDice(5, 10);
            gameState.knight.hp = 100 + rollDice(10, 10);
            break;
        case 'difficile':
            gameState.dragon.hp = 100 + rollDice(10, 10);
            gameState.knight.hp = 100 + rollDice(7, 10);
            break;
        default: // normal
            gameState.dragon.hp = 100 + rollDice(10, 10);
            gameState.knight.hp = 100 + rollDice(10, 10);
    }
    
    gameState.dragon.maxHP = gameState.dragon.hp;
    gameState.knight.maxHP = gameState.knight.hp;
    
    displayGameState();
}

// Affichage de l'état du jeu
function displayGameState() {
    const stateDiv = document.createElement('div');
    stateDiv.className = 'game-state';

    // Calcul des PV en pourcentage
    const knightHPPercent = Math.round((gameState.knight.hp / gameState.knight.maxHP) * 100);
    const dragonHPPercent = Math.round((gameState.dragon.hp / gameState.dragon.maxHP) * 100);

    stateDiv.innerHTML = `
        <figure class="game-state_player">
            <img src="images/${gameState.knight.hp / gameState.knight.maxHP < 0.3 ? 'knight-wounded.png' : 'knight.png'}" alt="Chevalier">
            <figcaption>
                <progress max="100" value="${knightHPPercent}"></progress>
                ${knightHPPercent}%
            </figcaption>
        </figure>
        <figure class="game-state_player">
            <img src="images/${gameState.dragon.hp / gameState.dragon.maxHP < 0.3 ? 'dragon-wounded.png' : 'dragon.png'}" alt="Dragon">
            <figcaption>
                <progress max="100" value="${dragonHPPercent}"></progress>
                ${dragonHPPercent}%
            </figcaption>
        </figure>
    `;

    gameContainer.appendChild(stateDiv);
}


// Gestion d'un tour de jeu
function playRound() {
    gameState.round++;
    
    const roundDiv = document.createElement('div');
    roundDiv.innerHTML = `<h3>Tour n°${gameState.round}</h3>`;
    gameContainer.appendChild(roundDiv);
    
    // Initiative
    const knightInitiative = rollDice(10, 6);
    const dragonInitiative = rollDice(10, 6);
    
    let attacker, defender, resultText;
    if (knightInitiative > dragonInitiative) {
        attacker = 'knight';
        defender = 'dragon';
        resultText = 'Vous êtes le plus rapide, vous attaquez le dragon';
    } else {
        attacker = 'dragon';
        defender = 'knight';
        resultText = 'Le dragon prend l\'initiative et vous attaque';
    }
    
    // Calcul des dégâts
    let damage = rollDice(3, 6);
    
    // Application des modificateurs
    if (attacker === 'dragon') {
        if (gameState.difficulty === 'facile') {
            const reduction = rollDice(2, 6);
            damage -= Math.floor(damage * reduction / 100);
        } else if (gameState.difficulty === 'difficile') {
            const increase = rollDice(1, 6);
            damage += Math.floor(damage * increase / 100);
        }
    } else {
        if (gameState.difficulty === 'facile') {
            const increase = rollDice(2, 6);
            damage += Math.floor(damage * increase / 100);
        } else if (gameState.difficulty === 'difficile') {
            const reduction = rollDice(1, 6);
            damage -= Math.floor(damage * reduction / 100);
        }
    }
    
    // Application des dégâts
    gameState[defender].hp = Math.max(0, gameState[defender].hp - damage);
    
    // Affichage du tour
    const roundResultDiv = document.createElement('figure');
    roundResultDiv.className = 'game-round';
    roundResultDiv.innerHTML = `
        <img src="images/${attacker === 'knight' ? 'knight-winner.png' : 'dragon-winner.png'}" alt="${attacker === 'knight' ? 'Chevalier vainqueur' : 'Dragon vainqueur'}">
        <figcaption>${resultText} et lui inflige ${damage} points de dommage !</figcaption>
    `;
    
    gameContainer.appendChild(roundResultDiv);
    displayGameState();
    
    // Vérification fin de partie
    if (gameState.dragon.hp <= 0 || gameState.knight.hp <= 0) {
        endGame();
        return false;
    }
    
    return true;
}

// Fonction principale du jeu
function playGame() {
    // On joue un tour toutes les secondes pour mieux voir l'évolution
    const gameInterval = setInterval(() => {
        const continueGame = playRound();
        if (!continueGame) {
            clearInterval(gameInterval);
        }
    }, 1000);
}

// Fin de partie
function endGame() {
    const winner = gameState.dragon.hp <= 0 ? 'knight' : 'dragon';
    const endMessage = winner === 'knight' 
        ? 'Félicitations ! Vous avez vaincu le dragon !' 
        : 'Vous avez perdu le combat, le dragon vous a carbonisé !';
    
    const endDiv = document.createElement('footer');
    endDiv.innerHTML = `
        <h3>Fin de la partie</h3>
        <figure class="game-end">
            <figcaption>${endMessage}</figcaption>
            <img src="images/${winner === 'knight' ? 'knight-winner.png' : 'dragon-winner.png'}" alt="${winner === 'knight' ? 'Chevalier vainqueur' : 'Dragon vainqueur'}">
        </figure>
    `;
    
    gameContainer.appendChild(endDiv);
}